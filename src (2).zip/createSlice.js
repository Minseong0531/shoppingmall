import {createSlice} from '@reduxjs/toolkit';

const counterSlice = createSlice({
    name:'counter', //이름
    initialState:{value:0}, //상태초기값 객체로 설정
    reducers:{
        increment:(state)=>{ state.value+=1},
        decrement:(state)=>{ state.value-=1},
    },
})

export const {increment, decrement} = counterSlice.actions;
export default counterSlice.reducer