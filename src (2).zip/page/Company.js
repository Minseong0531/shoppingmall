import { Outlet } from "react-router-dom";


function Company(){

    return(
        <div className="Company">
            <h1>회사소개</h1>
            <p>
                우리는 ....브랜드를 통해서 <br />
                고객의 삶을 향상 시키는 목표를 가지려고 노력하고 있습니다.
            </p>
            <Outlet />
        </div>
    )
}

export default Company;