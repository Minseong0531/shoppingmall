import { useParams, useNavigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Button } from "react-bootstrap";

function Detail({newPdt, addToCart}){
    const navigate = useNavigate();
    const {id} = useParams();
    let numId = parseInt(id) - 1;
    if(isNaN(numId) || numId<0 || numId>=newPdt.length){
        return(<div>해당상품이 존재하지 않습니다.</div>)
    }

    const product = newPdt[numId];

    return(
        <Container>
            <div className="detail">
                <h2>상세페이지</h2>
                <img src={`/img/${product.src}`} alt="" />
                <h3>{product.title}</h3>
                <p>설명 : {product.text} </p>
                <p>가격 : {product.price} </p>
                <Button variant="danger" onClick={()=>{addToCart(product)}}>주문하기</Button>
                <Button variant="primary" onClick={()=>{navigate("/cart")}}>장바구니 바로가기</Button>

            </div>
        </Container>
    )
}

export default Detail;