import './App.css';
import {Provider, useSelector, useDispatch} from 'react-redux';
import store from './store';
import { increment, decrement } from './createSlice';

function Counter(){
  //state : 전체 store , state.counter : 등록한 리듀서
  const count = useSelector((state)=>state.counter.value);
  const dispatch = useDispatch();
  return(
    <div>
      <h1>{count}</h1>
      <button onClick={()=> dispatch(increment())}>increment</button>
      <button onClick={()=> dispatch(decrement())}>decrement</button>
    </div>
  )
}

function App() {

  return (
    <Provider store={store}>
      <Counter />
    </Provider>
  );
}

export default App;
