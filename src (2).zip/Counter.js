function Counter(){
    return(
        <div>
            <p>Count : {}</p>
            <button> increment </button>
            <button> decrement </button>
        </div>
    )
}

export default Counter;