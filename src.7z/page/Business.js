
function Business(){

    return(
        <div className="Business">
            <h3>사업영역</h3>
            <p>고객라이프 스타일을 창조하기 위해 의식주를 <br />
            아우르는 다양한 사업 분야에 도전하고 있습ㄴ디ㅏ.</p>
        </div>
    )
}

export default Business;