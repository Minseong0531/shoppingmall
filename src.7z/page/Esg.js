
function Esg(){

    return(
        <section>
            <div className="esg">
                <img src="/img/1672995210796.jpg" width="100%" alt="" />
            </div>
        </section>
    )
}

export default Esg;