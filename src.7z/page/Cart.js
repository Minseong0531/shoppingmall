import { Container, Row, Col, Button } from "react-bootstrap";

function Cart({cartItems, removeFromCart}){
    return(
        <Container>
            <h2>장바구니</h2>
            <Row>
                {
                    cartItems.length===0? (
                        <Col><p>장바구니가 비었습니다.</p></Col>
                    ) : (
                        cartItems.map((item, idx)=>(
                            <Col md={3} key={idx} className="mb-4">
                                <img src={`/img/${item.src}`} width={"50%"} alt="" />
                                <h4>{item.title}</h4>
                                <p>{item.price}</p>
                                <Button variant="danger" onClick={()=>{removeFromCart(item.id)}}>목록 삭제</Button>
                            </Col>
                        ))
                    )
                }
            </Row>
        </Container>
    )
}

export default Cart;