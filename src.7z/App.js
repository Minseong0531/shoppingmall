import './App.css';
import { increment, decrement } from './createSlice';
import Controls from './components/Controls'
import React, { useState } from 'react';

function App() {
  const [num, setNum] = useState(10);
  const increase = () => {setNum(num+1);}
  const decrease = () => {setNum(num-1);}
  return (
    <div className="App">
      <h2>결과 {num}</h2>
      <Controls increase={increase} decrease={decrease} />
    </div>
  );
}

export default App;
