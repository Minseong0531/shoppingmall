import React, { useState } from 'react';

function Controls({increase, decrease}){
    return(
        <div>
            <button onClick={increase}>증가</button>
            <button onClick={decrease}>감소</button>
        </div>
    )
}

export default Controls;