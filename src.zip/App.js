import './App.css';
import Business from "./page/Business";
import Company from "./page/Company";
import Detail from "./page/Detail";
import Esg from "./page/Esg";
import {useState,useEffect} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import {Routes, Route, useNavigate} from 'react-router-dom'
import axios from 'axios';
import {Navbar, Nav, NavDropdown, Container, Row, Col} from 'react-bootstrap';
import Cart from './page/Cart';

function Main({newPdt}) {

  return(
    <section>
      <div className='main-visual'>
        <img src='/img/1672995210793.jpg' width="100%" alt=''></img>
      </div>
      <Container>
        <Row>
          {
            newPdt.map((item, idx)=>
            <Colmd content={item} key={idx}/>
            )
            
          }
        </Row>
      </Container>
    </section>
  )
}

function Colmd({content}){
  const navigate = useNavigate();
  return(
    <Col md={3}>
      <img src={`/img/${content.src}`} width="90%" alt='' 
          onClick={()=>{navigate(`/detail/${content.id}`)}}/>
      <h4>{content.title}</h4>
      <p>{content.text}</p>
      <p>{content.price}</p>
    </Col>
  )
}

function App() {
  const Navigate = useNavigate();
  const [newPdt, setNewPdt] = useState([]);
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (item) =>{
    setCartItems([...cartItems, item])
  }
  const removeFromCart = (id) =>{
    setCartItems(cartItems.filter(item=>item.id!==id))
  }

  useEffect(()=>{
    const fetchData = async() =>{
      try{
        const response = await axios.get('/data.json');
        setNewPdt(response.data);
      } catch(error){
        console.error('Error fetching data : ', error);
      }
    }
    fetchData();
  },[]);
  return (
    <div className="App">
<Navbar expand = "lg">
    <Navbar.Brand className="logo"></Navbar.Brand>
    <Navbar.Toggle aria-controls="navber-nav "/>
    <Navbar.Collapse id="navbar-nav">
      <Nav>
        <Nav.Link onClick={()=> Navigate("/")}>Home</Nav.Link>
        <NavDropdown title="Company" id="nav-dropdown">
          <NavDropdown.Item onClick={()=> Navigate("/company")}>INTRODUCTION</NavDropdown.Item>
          <NavDropdown.Item onClick={()=> Navigate("/company/business")}>BUSINESS AREA</NavDropdown.Item>
          <NavDropdown.Item onClick={()=> Navigate("/company/esg")}>ESG</NavDropdown.Item>
        </NavDropdown>
        <Nav.Link onClick={()=> Navigate("/cart")}>Cart</Nav.Link>
      </Nav>
    </Navbar.Collapse>
  </Navbar>
  <Routes>
    <Route path='/' element={<Main newPdt={newPdt}/>} />
    <Route path='/company' element={<Company />}>
      <Route path='business' element={<Business />} />
      <Route path='esg' element={<Esg />} />
    </Route>
    <Route path='/detail/:id' element={<Detail newPdt={newPdt} addToCart={addToCart}/>} />
    <Route path='/cart' element={<Cart cartItems={cartItems} removeFromCart={removeFromCart}/>} />
  </Routes>
    </div>
  );
}

export default App;
