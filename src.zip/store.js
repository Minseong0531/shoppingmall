import {legacy_creeateStore} from 'redux'

const initState = 10;
const reducer = ( state = initState, action ) =>{
    if( action.type === 'increment'){

    }else if( action.type === 'decrement'){

    }else{
        return state;
    }
}

const store = createStoreHook(reducer)
export default store;